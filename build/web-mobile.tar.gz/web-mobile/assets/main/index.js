System.register("chunks:///_virtual/jiakao3.ts",["./rollupPluginModLoBabelHelpers.js","cc"],(function(s){"use strict";var e,t,r,n,o,i,a,l;return{setters:[function(s){e=s.applyDecoratedDescriptor,t=s.inheritsLoose,r=s.initializerDefineProperty,n=s.assertThisInitialized},function(s){o=s.cclegacy,i=s._decorator,a=s.Label,l=s.Component}],execute:function(){var p,h,u,d,w,b,c;o._RF.push({},"4c8aaUIL91HBaMoE7fbRfwh","jiakao3",void 0);var m,f=i.ccclass,A=i.property,g=function(s,e){this.problem=void 0,this.answer=void 0,this.problem=s,this.answer=e};!function(s){s[s.PROBLEM=1]="PROBLEM",s[s.ANSWER=2]="ANSWER"}(m||(m={}));s("jiakao3",(p=f("jiakao3"),h=A(a),u=A(a),p((b=e((w=function(s){function e(){for(var e,t=arguments.length,o=new Array(t),i=0;i<t;i++)o[i]=arguments[i];return e=s.call.apply(s,[this].concat(o))||this,r(e,"lbl_problem",b,n(e)),r(e,"lbl_answer",c,n(e)),e.delta=0,e.lastUpdate=0,e.pos=-1,e.state=m.PROBLEM,e.problemsAnswers=new Array,e.randPos=new Array,e}t(e,s);var o=e.prototype;return o.start=function(){this.delta=0,this.lastUpdate=0,this.problemsAnswers.push(new g("同方向近距离跟车行驶","近光灯")),this.problemsAnswers.push(new g("通过有信号灯控制的路口","近光灯")),this.problemsAnswers.push(new g("在有路灯，照明良好的道路上行驶","近光灯")),this.problemsAnswers.push(new g("通过急弯","交替远近光灯两次")),this.problemsAnswers.push(new g("通过坡道","交替远近光灯两次")),this.problemsAnswers.push(new g("通过拱桥","交替远近光灯两次")),this.problemsAnswers.push(new g("通过人行横道","交替远近光灯两次")),this.problemsAnswers.push(new g("通过没有交通信号灯控制的路口","交替远近光灯两次")),this.problemsAnswers.push(new g("超车","左转向灯-回-交替远近光灯两次-右转向灯-回")),this.problemsAnswers.push(new g("进入无照明的道路行驶","远光灯")),this.problemsAnswers.push(new g("夜间在照明不良的道路上行驶","远光灯")),this.problemsAnswers.push(new g("路边临时停车","示阔灯+危险报警闪光灯"));for(var s=0;s<this.problemsAnswers.length;s++)this.randPos.push(s)},o.update=function(s){this.delta+=s;this.delta-this.lastUpdate>1&&(this.doUpdate1s(),this.lastUpdate+=1)},o.updateProblem=function(s){console.log("pos:"+s),this.lbl_problem.string=this.problemsAnswers[s].problem,this.lbl_answer.string=""},o.updateAnswer=function(s){console.log("pos:"+s),this.lbl_answer.string=this.problemsAnswers[s].answer},o.reRand=function(){console.log("reRand pos:"+this.pos),this.pos=0;for(var s=0;s<this.randPos.length;s++){var e=Math.floor(Math.random()*this.randPos.length),t=this.randPos[s];this.randPos[s]=this.randPos[e],this.randPos[e]=t}},o.doUpdate1s=function(){if(console.log("doUpdate1s this.lastUpdate:"+this.lastUpdate+" length:"+this.problemsAnswers.length),(this.pos<0||this.pos>=this.problemsAnswers.length)&&this.reRand(),this.lastUpdate%6!=0)return this.lastUpdate%6==4?(this.updateAnswer(this.randPos[this.pos]),void this.pos++):void 0;this.updateProblem(this.randPos[this.pos])},e}(l)).prototype,"lbl_problem",[h],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),c=e(w.prototype,"lbl_answer",[u],{configurable:!0,enumerable:!0,writable:!0,initializer:function(){return null}}),d=w))||d));o._RF.pop()}}}));

System.register("chunks:///_virtual/main",["./jiakao3.ts"],(function(){"use strict";return{setters:[null],execute:function(){}}}));

(function(r) {
  r('virtual:///prerequisite-imports/main', 'chunks:///_virtual/main'); 
})(function(mid, cid) {
    System.register(mid, [cid], function (_export, _context) {
    return {
        setters: [function(_m) {
            var _exportObj = {};

            for (var _key in _m) {
              if (_key !== "default" && _key !== "__esModule") _exportObj[_key] = _m[_key];
            }
      
            _export(_exportObj);
        }],
        execute: function () { }
    };
    });
});